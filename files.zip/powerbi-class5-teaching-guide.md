# POWER BI CLASS 5 — TEACHING GUIDE
## Building Dashboards: Visuals, Design & Interactivity
**XELI AI LABS • Data Analytics Program • Phase 3, Week 2**
**Duration:** 2.5 hours | **Slides:** `powerbi-class5-slides.html` (28 slides)
**Demo data:** the **NaijaStream** model (with the measures from today's solve-together) | **Assignment:** `chopnow_raw.xlsx` + `orders_20XX.csv` (fresh, messy)

---

## 👋 READ THIS FIRST (Instructor Note)

Today's class comes **right after** the solve-together walkthrough, so everyone already has the NaijaStream model open with measures on it (Total Revenue, Number of Views, Unique Subscribers, Avg Watch Time, Premium Revenue, Revenue YTD). **No warm-up needed** — we go straight from "we have measures" to "let's build a dashboard with them."

The clicking today is easy but there's *a lot* of it. Two habits keep the room together:
1. **Demo one thing, then wait** until everyone's screen matches before moving on.
2. **For every visual, say what question it answers and point at what changed on screen.** A dashboard is about communication, so narrate the communication.

**Before class:** build the NaijaStream dashboard once yourself (~20 min) so you know where each button is on the current UI. Have `chopnow.xlsx` ready to send with the assignment.

**📂 Which files go to whom:**
- **Give students (in class):** `powerbi-class5-exercises.docx`. They build on their **own NaijaStream file**.
- **Give students (assignment):** `powerbi-class5-assignment.docx` + `chopnow_raw.xlsx` + `orders_2024.csv`, `orders_2025.csv`, `orders_2026.csv`.
- **Keep for yourself:** this guide, `powerbi-class5-slides.html`, `powerbi-class5-exercises-SOLUTIONS.docx`, `powerbi-class5-assignment-SOLUTIONS.docx`.

**Vocabulary for today:**
- **Report page** = one screen/tab of your report (the tabs at the bottom). A "dashboard" here = a well-designed report page.
- **Visual** = any chart, card, table, slicer, or map on the page.
- **Card** = a visual that shows one big number.
- **Slicer** = an on-screen filter the viewer can click.
- **Cross-filtering** = clicking part of one visual filters the others.
- **Drill-down / drill-through / bookmark** = the three interactivity tools (defined in Segment 6).

---

## ⏱️ TIMING OVERVIEW (maps to the 28 slides)

| # | Segment | Time | Slides |
|---|---------|------|--------|
| 1 | Recap & what makes a good dashboard | 15 min | 1–5 |
| 2 | Design principles | 20 min | 6–8 |
| 3 | Choosing the right visual | 20 min | 9–14 |
| 4 | Build it: cards, charts, slicers | 30 min | 15–17 |
| 5 | Format & theme | 15 min | 18–20 |
| 6 | Interactivity: drill-down, drill-through, bookmarks | 30 min | 21–23 |
| 7 | Practice, career, assignment, recap | 20 min | 24–28 |

---

## SEGMENT 1 — RECAP & WHAT MAKES A GOOD DASHBOARD (15 min) — Slides 1–5

Recap (Slides 1–3): connect → clean → model → measures → **now we make it visible**. Frame it (Slide 4): a pile of cards isn't a dashboard; a dashboard answers the key questions on one screen, is organised, and lets people explore.

Good vs bad (Slide 5): read both lists. Land the **5-second rule** — show a dashboard for 5 seconds; if the viewer can't say the main message, it's too busy. This is the yardstick for everything today.

---

## SEGMENT 2 — DESIGN PRINCIPLES (20 min) — Slides 6–8

Three principles, each with a concrete "what good looks like."
- **Layout (Slide 6):** people read top-left → down. So **KPI cards on top**, main charts in the middle, detail/slicers to the side. The eye should hit the headline numbers first.
- **Less is more (Slide 7):** whitespace helps; clutter hurts. Every visual must answer a question — if you can't name the question, delete it.
- **Consistency (Slide 8):** one accent colour for the important measure, grey for the rest; align to a grid; format numbers the same everywhere.

> 🗣️ Show a deliberately ugly dashboard (or describe one: 15 rainbow charts, no titles) then the clean version. The contrast sells the principles faster than any rule.

---

## SEGMENT 3 — CHOOSING THE RIGHT VISUAL (20 min) — Slides 9–14

The core idea (Slide 9): each visual answers a **type of question**. Teach the match, with the "what it's for / how / what you'll see" for each:
- **Card (Slide 10):** one headline number. Drag a measure → click Card.
- **Bar/Column (Slide 11):** compare categories. Measure in Values, category in Axis. *Always sort it* so the biggest is first.
- **Line (Slide 12):** change over time. Date on X, measure on Y. Rule to repeat: **time → line, categories → bars.**
- **Table/Matrix (Slide 13):** exact detail. Table = list; Matrix = rows × columns (pivot).
- **Map (Slide 14):** geography only. **Location** = a place field (e.g. `subscribers[city]`); **Bubble size** = a measure (e.g. `Number of Views` or `Total Revenue`) — bigger bubble = more of that measure in the city. Needs internet.

> 🚫 Hammer the anti-pie message (Slide 9/11): pie charts fail past 2–3 slices because people can't compare angles. Default to a bar.

---

## SEGMENT 4 — BUILD IT: CARDS, CHARTS, SLICERS (30 min) — Slides 15–17

**🎯 LIVE DEMO on the NaijaStream model. Everyone follows. Go slowly and name every click.**

### Start with KPI cards (Slide 15)
1. At the **bottom of the screen**, click the **+** next to the page tabs to make a **new blank report page** (keep our demo clean).
2. In the **Data pane** (right), tick **Total Revenue** — a visual appears. With it selected, click the **Card** icon in the **Visualizations** pane (top row of icons — hover to find "Card").
3. Do the same for **Number of Views**, **Unique Subscribers**, **Avg Watch Time** (each: tick the measure → click Card).
4. Drag the four cards into a **row across the top**. (Don't fuss over exact alignment yet — Segment 5.)
> **What you'll see:** a strip of four big numbers. Say: *"That's the headline of our dashboard — the first thing anyone reads."*

### Add the main charts (Slide 16)
Make each on an empty part of the canvas:
1. **Revenue by plan** — click empty canvas → in Visualizations click **Clustered column chart** → drag **Total Revenue** into the **Y-axis** well, and **plan** (from payments or subscribers) into the **X-axis** well.
2. **Views by genre** — empty canvas → **Clustered bar chart** → **Number of Views** into Values, **genre_name** (from content) into Axis → click the visual's **⋯ menu → Sort axis → Number of Views → Descending**.
3. **Revenue over time** — empty canvas → **Line chart** → **Calendar[Month]** on X-axis, **Total Revenue** on Y-axis. (If months are scrambled: click Month in Data pane → Column tools → Sort by column → MonthNo.)
> **What you'll see:** three charts each answering a different question — compare (plan), rank (genre), trend (time). Point out that *together with the cards this is already a working dashboard.*

### Slicers & cross-filtering (Slide 17)
1. Click empty canvas → in Visualizations click the **Slicer** icon → drag **Calendar[year]** (or **device**) into it. It becomes a clickable filter box.
2. **Cross-filtering is automatic:** click any **bar** in the genre chart.
> **What you'll see (do this live, it's the "wow"):** click "Comedy" on the genre chart → the four cards, the line chart, and the plan chart *all instantly update to Comedy only*. Click it again to clear. Say: *"You didn't write any code for that — relationships from Class 3 make every visual talk to every other visual."*

---

## SEGMENT 5 — FORMAT & THEME (15 min) — Slides 18–20

### Format visuals (Slide 18)
Select a visual → in the Visualizations pane click the **Format** icon (the **paint-roller** 🖌️). Demo on one chart:
- **Title:** turn it on / rename to something human ("Revenue by Plan").
- **Data labels:** turn on so numbers show on the bars.
- **Colours:** set one accent colour; consider greying secondary bars.
> **What you'll see:** the chart goes from bare to intentional. Say: *"80% of 'looking professional' is titles + data labels + one colour."*

### Themes (Slide 19)
**View** ribbon → **Themes** → pick one from the gallery.
> **What you'll see:** the whole report re-colours in one click — consistent instantly. Then **Insert → Text box** at the top: type "NaijaStream — Performance Dashboard", make it big. A titled report reads as finished.

### Align & arrange (Slide 20)
Resize by dragging corner handles; move by dragging the body. Turn on **View → Gridlines** and **Snap to grid**. To line things up: Ctrl+click several visuals → **Format** tab → **Align** (e.g. Align top, Distribute horizontally).
> **What you'll see:** cards perfectly level, even gaps. Say: *"This is the single biggest 'student vs professional' difference — alignment."*

---

## SEGMENT 6 — INTERACTIVITY: DRILL-DOWN, DRILL-THROUGH, BOOKMARKS (30 min) — Slides 21–23

**Three separate features. Do each fully, and show the result each time.**

### Drill-down (Slide 21) — zoom into detail inside one chart
1. Take the **revenue-over-time line chart**. Into its **X-axis** well, add more date fields so it's a hierarchy: **year**, then **Month**, then (optionally) a day field — stacked in that order.
2. Little **arrows** appear at the **top-right of the visual**. The **double-down arrow ⤓** turns on "drill mode".
3. Click the ⤓ so it's on, then **click a point/bar**.
> **What you'll see:** start on years → click **2025** → the chart redraws into 2025's **months** → click a month → its **days**. The **up-arrow** climbs back out. Say: *"One chart, three levels of zoom — the viewer explores without you building three charts."*

### Drill-through (Slide 22) — jump to a detail page for one item
1. Make a **new page** (the **+** at the bottom). This is the "detail" page. Put a couple of visuals on it — e.g. a **Table** of content titles + Number of Views, and a card or two.
2. In the **Visualizations** pane on that page, find the **Drill through** section (below the field wells) → drag **genre_name** into the **"Add drill-through fields here"** box. A **back-arrow button** appears on the page automatically (keep it).
3. Go back to the **main page** → **right-click a bar** in the genre chart → in the menu choose **Drill through → [your detail page name]**.
> ⚠️ **Order matters — this is the #1 confusion:** the "Drill through" option does **not** appear in the right-click menu until you've done steps 1–2 (a destination page with a field in its Drill through well). If you right-click and see no "Drill through", it's because the detail page isn't set up yet — not because you did the right-click wrong. Set up the page first, then right-click.
> **What you'll see:** right-click "Comedy" → you jump to the detail page showing **only Comedy's** content and numbers. The back button returns you. Say: *"It's a 'tell me more about this one' link — exactly what managers ask for."*
> 🗣️ The field you drag into the Drill through well (genre_name) must be the same field you right-click on — right-click a *genre* bar to reach a *genre* detail page.

### Bookmarks & buttons (Slide 23) — flip one spot between two views

**The idea (plain English):** a **bookmark** is a **saved snapshot** of the page — it remembers which visuals are showing and any filters at the moment you save it. Make two snapshots, put a **button** on each, and clicking a button flips the dashboard to that snapshot. We'll build a toggle that flips one chart-slot between a **Revenue** view and a **Views** view — genuinely different data in the same space. Demo this slowly; it has the most steps of anything today.

**① Build the two charts and stack them in the same spot**
1. Make **Chart A** — a Clustered bar: Values = **Total Revenue**, Axis = **genre_name**. Title it "Revenue by Genre".
2. Make **Chart B** — a Clustered bar: Values = **Number of Views**, Axis = **genre_name**. Title it "Views by Genre".
3. Drag **Chart B directly on top of Chart A** so they cover the same area and are the same size. They'll overlap in edit mode — that's expected, because we'll only ever show **one at a time**.

**② Open the two panes you need**
4. On the **View** ribbon, tick **Selection** and tick **Bookmarks**. Two panes open on the right:
   - The **Selection** pane lists every visual on the page, each with an **eye icon (👁)** to show or hide it.
   - The **Bookmarks** pane is where you save snapshots.

**③ Make Bookmark 1 — "Revenue"**
5. In the **Selection** pane, click the **eye** next to **"Views by Genre"** to **hide** it. Make sure **"Revenue by Genre"** is **showing**. Now only the Revenue chart is visible on the page.
6. In the **Bookmarks** pane click **Add**. It creates "Bookmark 1" — double-click it and rename it **Revenue**. *(The bookmark just memorised "Revenue chart visible, Views chart hidden".)*

**④ Make Bookmark 2 — "Views"**
7. Flip the visibility: in the **Selection** pane, **show** "Views by Genre" and **hide** "Revenue by Genre". Now only the Views chart is visible.
8. In the **Bookmarks** pane click **Add** again → rename it **Views**.

**⑤ Add the two buttons (this is where the "settings" matter)**
9. **Insert** ribbon → **Buttons** → **Blank**. A button drops onto the page — move it above the chart.
10. With that button selected, open its **Format** pane (paint-roller). Find **Action** and switch it **On**. Set **Action → Type = Bookmark**, then **Action → Bookmark = Revenue**. Then give it a label: Format → **Text** → turn on, type "Revenue".
11. Add the **second button**: Insert → Buttons → Blank again → select it → Format → **Action On** → **Type = Bookmark** → **Bookmark = Views** → Text = "Views". Place it next to the first button.
> 🔑 The ONLY difference between the two buttons is the **Bookmark** each one points to (Revenue vs Views). Everything else (Action On, Type = Bookmark) is identical. That single setting is what makes each button show its own data.

**⑥ Test it**
12. In edit mode you must **hold Ctrl and click** a button (once the report is published, a normal single click works).
> **What you'll see:** click the **Revenue** button → the slot shows *Revenue by Genre*; click the **Views** button → the SAME slot flips to *Views by Genre*. Same space, different data. Say: *"That's how you fit two dashboards' worth of story into one screen."*

> ⚠️ **The three things that trip people up:**
> - A bookmark saves the state **at the moment you clicked Add**. Changed the page afterwards and want the bookmark to match? Right-click the bookmark → **Update**.
> - Button does nothing? Check its **Action** is **On**, **Type = Bookmark**, a **Bookmark is chosen** — and that you **Ctrl+click** in edit mode.
> - Both buttons show the same thing? They're pointing at the same bookmark — re-open each button's Action and confirm one says **Revenue**, the other **Views**.

---

## SEGMENT 7 — PRACTICE, CAREER, ASSIGNMENT, RECAP (20 min) — Slides 24–28

### ✏️ Practice (Slide 24) — hand out `powerbi-class5-exercises.docx`
On NaijaStream: 3–4 KPI cards, a bar + a line chart, a slicer, titles on everything, a theme; bonus drill-down. Circulate — most issues are alignment and forgetting titles.

### Career Corner (Slide 25)
The dashboard is the **visible** deliverable — what managers, clients and interviewers actually see. Two analysts with the same data: the one who delivers a clean, focused, interactive dashboard gets hired. Read the CV line.

### Assignment (Slide 26)
Hand out `powerbi-class5-assignment.docx` + the raw files: `chopnow_raw.xlsx` and `orders_2024/2025/2026.csv`. It's the **capstone** on a fresh, **messy** food-delivery dataset — the full pipeline: **clean & combine (C2) → model (C3) → measures (C4) → dashboard (C5)**. They clean 3 messy tables, append the 3 order files, merge cuisine, add custom/conditional columns, then model, measure, and build the dashboard. Stress this is their **biggest portfolio piece yet** — everything from Phase 3 on unseen data. `chopnow_clean.xlsx` is your answer key / fallback. Give them until the next class.

### Recap + next (Slides 27–28)
Recap: good design, right visuals, build cards/charts/slicers, format/theme, drill-down/through/bookmarks. Preview Class 6 — **publishing & sharing** and pulling it into a portfolio-ready capstone. End on Slide 28: *"If they have to ask what it means, the dashboard isn't finished yet."*

---

## ✅ END-OF-CLASS CHECKLIST
Every student should be able to:
- [ ] Lay out a page with KPI cards on top and charts below
- [ ] Pick the right visual for a question (card / bar / line / table / map)
- [ ] Build cards, a bar chart (sorted), a line chart, and a slicer
- [ ] Explain cross-filtering (click a bar → everything filters)
- [ ] Add titles + data labels and apply a theme
- [ ] Align visuals to a grid
- [ ] Turn on drill-down, set up a drill-through page, and make a bookmark + button

## 🆘 TROUBLESHOOTING CHEAT SHEET
| Problem | Fix |
|---|---|
| Dragged a measure but it made a table, not a card | Select the visual → click the **Card** icon in Visualizations |
| Chart shows one giant bar / no split | You put a measure where a category goes (or vice versa) — a **category** goes on the Axis, a **measure** in Values |
| Bar chart isn't sorted | Visual's **⋯ menu → Sort axis →** your measure → Descending |
| Months out of order on the line | Data pane → click **Month** → Column tools → **Sort by column → MonthNo** |
| Map is blank | Needs internet to load tiles; also check the Location field is a real place (city/state) |
| Drill-down arrows missing | The axis needs **more than one field** (year, then month…) for a hierarchy to exist |
| "Drill through" missing/greyed in the right-click menu | You haven't set up the destination page yet. On the detail page, drag the field (e.g. genre_name) into the **Drill through** well *first* — the option only appears once a destination exists |
| Button does nothing when clicked in edit mode | Hold **Ctrl** and click (edit mode); a plain click works once published |
| Everything filtered and won't reset | Click the selected bar/slicer value again, or use the eraser on the slicer, to clear the filter |

---
**XELI AI LABS • Phase 3: Power BI • Class 5 of 6**
